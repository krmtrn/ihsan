document.addEventListener('DOMContentLoaded', function() {
    const yesBtn = document.getElementById('yes-btn');
    const noBtn = document.getElementById('no-btn');
    const celebrationMessage = document.getElementById('celebration-message');

    // Initialize music
    const synth = new Tone.PolySynth().toDestination();
    const melody = [
        ["E4", "G4", "B4"],
        ["E4", "G4", "B4"],
        ["D4", "F4", "A4"],
        ["E4", "G4", "B4"]
    ];
    let isPlaying = false;
    let currentChord = 0;

    function playNextChord() {
        if (!isPlaying) return;
        synth.triggerAttackRelease(melody[currentChord], "2n");
        currentChord = (currentChord + 1) % melody.length;
        setTimeout(playNextChord, 2000);
    }

    function startMusic() {
        if (!isPlaying) {
            isPlaying = true;
            Tone.start();
            playNextChord();
        }
    }

    // Start music on first interaction
    document.body.addEventListener('click', startMusic, { once: true });

    yesBtn.addEventListener('click', function() {
        celebrationMessage.classList.remove('hidden');
        celebrate();
    });

    noBtn.addEventListener('mouseover', function() {
        const maxX = window.innerWidth - noBtn.offsetWidth;
        const maxY = window.innerHeight - noBtn.offsetHeight;

        const randomX = Math.random() * maxX;
        const randomY = Math.random() * maxY;

        noBtn.style.position = 'fixed';
        noBtn.style.left = randomX + 'px';
        noBtn.style.top = randomY + 'px';
    });

    noBtn.addEventListener('click', function() {
        const messages = [
            "Oyun Bitti! Devam etmek için EVET butonuna tıklayın ❤️",
            "Yanlış Buton! EVET butonunu arıyordunuz!",
            "EVET butonunu deneyin!",
            "Prensiniz EVET butonunda sizi bekliyor👑",
            "Aşk Olsun İhsan! 💕",
            "Player 2 can't say NO! Tekrar deneyin! 🎮"
        ];
        const randomMessage = messages[Math.floor(Math.random() * messages.length)];
        alert(randomMessage);
    });

    function celebrate() {
        const duration = 15 * 1000;
        const animationEnd = Date.now() + duration;
        const defaults = { startVelocity: 30, spread: 360, ticks: 60, zIndex: 0 };

        function randomInRange(min, max) {
            return Math.random() * (max - min) + min;
        }

        const interval = setInterval(function() {
            const timeLeft = animationEnd - Date.now();

            if (timeLeft <= 0) {
                return clearInterval(interval);
            }

            const particleCount = 50 * (timeLeft / duration);

            // Mario coin sound effect colors
            confetti({
                ...defaults,
                particleCount,
                origin: { x: randomInRange(0.1, 0.3), y: Math.random() - 0.2 },
                colors: ['#ffd700', '#ffb900', '#ff9100']
            });
            confetti({
                ...defaults,
                particleCount,
                origin: { x: randomInRange(0.7, 0.9), y: Math.random() - 0.2 },
                colors: ['#ffd700', '#ffb900', '#ff9100']
            });
        }, 250);
    }
});